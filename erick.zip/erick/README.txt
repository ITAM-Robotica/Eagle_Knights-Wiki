El paquete proyecto1 esta dentro de la carpeta descomprimida "erick", el archivo ejecutable es "robotTurtle".
Funciona escribiendo en la interfaz cordenadas X y Y segun te las solicite para mover a la tortuga a esa posicion final.
Escribiendo un angulo final para completar la "pose".
Y escribiendo el tiempo requerido.

Fin :)


Autor: Erick Zetina Muciño. C.U. 150766
